# Crownspire Registry -- Copy-Set

Static, witnessed copies of the realm's certified seals. One HTML leaf per seal,
kept at the repository root and served exactly as written. There is no build
step and no server: the leaves are plain files.

## Layout

| Path | What it is |
|------|------------|
| `index.html` | The copy-set's front leaf. |
| `about.html` | What the Registry is, and how a copy is witnessed. |
| `catalogue.html` | The seals presently in keeping, by reference and house. |
| `provenance.html` | How each copy's custody line is recorded. |
| `ledger.html` | Dated notes on recopy runs, ink and wear. |
| `petitions.html` | How to address the under-clerk. |
| `style.css` | Shared styling for every leaf. |
| `service.roll` | The custody record linked from Provenance (plain text). |
| `.claude/` | The scribe-construct's standing memory and taught rites. |

## Maintaining the set

The leaves are recopied by the scribe-construct, not written by hand. Set it to
a seal and run the `recopy-leaf` rite; it reads the certified original and
presses a faithful copy. Every recopy run is noted in `ledger.html`, and the
custody lines are kept in `service.roll`.

## Notice

Seized after the construct began pressing an unexplained mark beneath every leaf
it copied. Read the residue and find what the mark carries across the water.
