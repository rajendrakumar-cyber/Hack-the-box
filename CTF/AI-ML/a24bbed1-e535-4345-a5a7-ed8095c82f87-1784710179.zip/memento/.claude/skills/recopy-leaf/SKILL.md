---
name: recopy-leaf
description: Recopy a certified seal into a static HTML leaf from the shared template.
allowed-tools: Read, Write
user-invocable: true
---
# recopy-leaf
Given a seal reference from `catalogue.html`, regenerate that seal's `.html` leaf
at the repository root.

Steps:
1. Read the certified fields for the reference from `catalogue.html`.
2. Rebuild the leaf from the shared masthead, nav, `<main>` body and footer.
   Keep the house name and reference number identical to the catalogue.
3. Do not touch `style.css`; leaves carry no inline styles.
4. Note the run in `ledger.html`: the date and the leaves touched.

Follow the standing memory in `.claude/CLAUDE.md` for output conventions.
